<div class="results hidden-hd">
    <div class="container">
        <div class="row justify-content-xxl-between">
            <div class="results__card">
                <h2><sup>$</sup>7.51 <span>Million</span></h2>
                <hr>
                <span class="sub-title">RIGGING GRIP ELECTRICAL & BURN INJURY</span>
            </div>
            <div class="results__card">
                <h2><sup>$</sup>5.57 <span>Million</span></h2>
                <hr>
                <span class="sub-title">RAILROAD BURN DEATH RESULT</span>
            </div>
            <div class="results__card">
                <h2><sup>$</sup>5 <span>Million</span></h2>
                <hr>
                <spa class="sub-title">WRONGFUL DEATH VERDICT</span>
            </div>
            <div class="results__card">
                <h2><sup>$</sup>4 <span>Million</span></h2>
                <hr>
                <span class="sub-title">BURN DEATH EXPLOSION RESULT</span>
            </div>
        </div>
    </div>
</div>